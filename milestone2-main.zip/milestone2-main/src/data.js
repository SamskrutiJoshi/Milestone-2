export const menuData = [
    { id: 1, name: "Pizza", category: "Main Course", price: "$12", image: "https://img.freepik.com/free-photo/top-view-pepperoni-pizza-with-mushroom-sausages-bell-pepper-olive-corn-black-wooden_141793-2158.jpg" },
    { id: 2, name: "Cake", category: "Desserts", price: "$8", image: "https://i.pinimg.com/736x/68/7a/0f/687a0fce847343caf121818d8b7baa5d.jpg" },
    { id: 3, name: "Salad", category: "Starters", price: "$6", image: "https://img.freepik.com/free-photo/salad-from-tomatoes-cucumber-red-onions-lettuce-leaves-healthy-summer-vitamin-menu-vegan-vegetable-food-vegetarian-dinner-table-top-view-flat-lay_2829-6482.jpg" },
    { id: 4, name: "Burger", category: "Main Course", price: "$10", image: "https://img.freepik.com/free-photo/grilled-gourmet-burger-with-cheese-tomato-onion-french-fries-generated-by-artificial-intelligence_25030-63181.jpg" },
    { id: 5, name: "Ice Cream", category: "Desserts", price: "$5", image: "https://img.freepik.com/premium-photo/chocolate-vanilla-strawberry-ice-cream-isolated-white_807701-3441.jpg" },
    { id: 6, name: "biriyani", category: "Main Course", price: "$20", image: "https://img.freepik.com/free-photo/veg-biryani-veg-pulav-fried-rice-indian-food-generative-ai_1258-151588.jpg"},
     { id: 7, name: "Fries", category: "Starters", price: "$13", image: "https://static.vecteezy.com/system/resources/previews/027/536/411/non_2x/delicious-french-fries-on-a-white-background-photo.jpg"},
    { id: 8, name: "Sandwich", category: "Main Course", price: "$7", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROBTHP2x-nW_zE0ctrfWLmFlgyX9zNkwLu1g&s"},
     { id: 9, name: "Fruit Salad", category: "Desserts", price: "$11", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgGcrNegvE2rHl0TnAlX-6W_LvZlOy9utgxg&s"},
     { id: 10, name: "Pasta", category: "Main Course", price: "$9", image: "https://img.freepik.com/free-photo/penne-pasta-tomato-sauce-with-chicken-tomatoes-wooden-table_2829-19744.jpg?semt=ais_hybrid"},

  ];
  